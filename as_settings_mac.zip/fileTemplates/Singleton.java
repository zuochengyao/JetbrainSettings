#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
#if (${VISIBILITY} == "PUBLIC")public #end class ${NAME} #if (${SUPERCLASS} != "")extends ${SUPERCLASS} #end #if (${INTERFACES} != "")implements ${INTERFACES} #end {
    private ${NAME}() {
    }
    
    private static volatile ${NAME} mInstance;

    #if (${VISIBILITY} == "PUBLIC")public #end static ${NAME} getInstance(){
        if (mInstance == null) {
            synchronized (${NAME}.class){
                if (mInstance == null)
                    mInstance = new ${NAME}() ;
            }
        }
        return mInstance ;
    }
}
